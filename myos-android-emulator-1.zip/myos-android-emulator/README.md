# MyOS Emulator for Android

Android Studio project for running MyOS `.app` binaries on Android.

## Architecture

- Parses the MyOS v2 `MYAP` header and validates image bounds.
- Provides a 32-bit x86 interpreter in Java for the instruction subset used by the SDK's GCC-built apps.
- Maps MyOS `int 0x80` syscalls to an Android Canvas/Bitmap display, Android input events, Android storage and a simple beep.
- Uses a single 640x480 virtual MyOS display and scales it to the phone screen.
- Uses Android Storage Access Framework so the user can choose any `.app` file.
- Ships three built-in MyOS games from the supplied SDK project.

## Build

Open the folder in Android Studio with an Android SDK installed. The project uses AGP 8.5.2, compileSdk 35, minSdk 26.

The environment used to generate this project did not contain the Android SDK/Gradle toolchain, so an APK could not be compiled here. The project itself is complete and intended to be built by Android Studio.

## Compatibility

This is a real emulator architecture, but "any app" is bounded by the implemented x86 instruction and syscall coverage. SDK applications using unsupported x86 instructions/syscalls will show a VM fault rather than silently producing wrong results. The VM is deliberately dependency-free; a production version should move the CPU core to C++/NDK and add full x87/SSE/CPUID/FPU and complete ABI coverage for near-total SDK compatibility.
