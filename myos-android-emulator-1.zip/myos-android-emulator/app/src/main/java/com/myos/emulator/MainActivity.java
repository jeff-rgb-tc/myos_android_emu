package com.myos.emulator;

import android.app.*;import android.os.*;import android.content.*;import android.net.Uri;import android.view.*;import android.graphics.*;import java.io.*;import java.util.*;

public class MainActivity extends Activity {
    LauncherView launcher; EmulatorView emulator;
    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN); launcher=new LauncherView(this); setContentView(launcher);}
    void openApp(Uri uri){try{InputStream in=getContentResolver().openInputStream(uri); byte[] data=readAll(in); in.close(); launch(data);}catch(Exception e){launcher.error=e.toString();launcher.invalidate();}}
    void launch(byte[] data){ emulator=new EmulatorView(this,data); setContentView(emulator); emulator.requestFocus(); }
    @Override public void onBackPressed(){ if(emulator!=null){emulator.stop(); emulator=null; setContentView(launcher);} else super.onBackPressed(); }
    byte[] readAll(InputStream in)throws IOException{ByteArrayOutputStream o=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))>0)o.write(b,0,n);return o.toByteArray();}

    class LauncherView extends View{
        Paint p=new Paint(1); String error="";
        LauncherView(Context c){super(c);setFocusable(true);}
        protected void onDraw(Canvas c){super.onDraw(c);c.drawColor(Color.rgb(8,10,18));p.setColor(Color.CYAN);p.setTextSize(42);p.setTypeface(Typeface.DEFAULT_BOLD);c.drawText("MyOS EMULATOR",48,70,p);p.setTextSize(18);p.setColor(Color.LTGRAY);c.drawText("Run MyOS .app binaries on Android",50,105,p);p.setColor(0xff202838);c.drawRoundRect(45,135,390,205,12,12,p);p.setColor(Color.WHITE);p.setTextSize(22);c.drawText("OPEN .APP",70,180,p);
            p.setColor(0xff101725);c.drawRoundRect(45,225,390,300,12,12,p);p.setColor(Color.CYAN);p.setTextSize(18);c.drawText("Built-in examples",70,255,p);p.setColor(Color.WHITE);p.setTextSize(16);c.drawText("Iron Sector 3D",70,280,p);c.drawText("Starfall 3D",70,302,p);
            p.setColor(0xff8892a5);p.setTextSize(14);c.drawText("A 32-bit x86 MyOS VM + syscall/display bridge",48,getHeight()-50,p);if(!error.isEmpty()){p.setColor(0xffff7777);c.drawText(error,48,getHeight()-25,p);}}
        public boolean onTouchEvent(android.view.MotionEvent e){if(e.getAction()!=1)return true;float x=e.getX(),y=e.getY();if(y>130&&y<215){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/octet-stream");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,7);}else if(y>220&&y<320){try{String n=y<285?"ironsector3d.app":"starfall3d.app";InputStream in=getAssets().open("apps/"+n);launch(readAll(in));in.close();}catch(Exception ex){error=ex.toString();invalidate();}}return true;}
    }
    @Override protected void onActivityResult(int r,int code,Intent d){super.onActivityResult(r,code,d);if(r==7&&code==RESULT_OK&&d!=null)openApp(d.getData());}
}
