package com.myos.emulator;

import android.content.*;import android.graphics.*;import android.media.*;import android.view.*;import java.io.*;import java.util.*;

public class EmulatorView extends View {
    final MyosVm vm; final Bitmap screen; final Paint paint=new Paint(); volatile boolean running=true; Thread thread;
    public EmulatorView(Context c,byte[] app){super(c);setFocusable(true);screen=Bitmap.createBitmap(640,480,Bitmap.Config.ARGB_8888);vm=new MyosVm(app,screen,this,c);thread=new Thread(()->{while(running&&!vm.halted){long t=System.nanoTime();try{vm.step(30000);}catch(Throwable x){vm.halted=true;vm.fault=x.toString();}postInvalidate();long ms=(System.nanoTime()-t)/1000000;try{Thread.sleep(Math.max(1,16-ms));}catch(Exception ignored){}}});thread.start();}
    public void stop(){running=false;vm.halted=true;}
    protected void onDraw(Canvas c){c.drawColor(Color.BLACK);float sx=getWidth()/(float)screen.getWidth(),sy=getHeight()/(float)screen.getHeight();float s=Math.min(sx,sy);float x=(getWidth()-screen.getWidth()*s)/2,y=(getHeight()-screen.getHeight()*s)/2;paint.setFilterBitmap(false);c.drawBitmap(screen,null,new RectF(x,y,x+screen.getWidth()*s,y+screen.getHeight()*s),paint);if(vm.fault!=null){paint.setColor(0xcc000000);c.drawRect(0,0,getWidth(),getHeight(),paint);paint.setColor(Color.RED);paint.setTextSize(22);c.drawText("MyOS VM fault",30,50,paint);paint.setTextSize(14);c.drawText(vm.fault,30,80,paint);}}
    public boolean onTouchEvent(MotionEvent e){return vm.touch(e);}
    public boolean onKeyDown(int k,KeyEvent e){vm.key(k,true);return true;} public boolean onKeyUp(int k,KeyEvent e){vm.key(k,false);return true;}
}
