# Сборка MyOS Emulator на телефоне через GitHub

## Вариант без ПК

1. Создай новый публичный или приватный репозиторий на GitHub, например `myos-android-emulator`.
2. Распакуй этот архив на телефоне.
3. Зайди в репозиторий → **Add file → Upload files**.
4. Загрузи **содержимое папки `myos-android-emulator`**, а не сам ZIP.
   В корне репозитория должны лежать `build.gradle`, `settings.gradle`, `gradle.properties`, папка `app` и `.github`.
5. Нажми **Commit changes**.
6. Открой вкладку **Actions**.
7. Выбери **Build MyOS Emulator APK**.
8. Нажми **Run workflow** (если workflow ещё не запускался автоматически).
9. Дождись зелёного статуса.
10. Открой завершённый запуск и внизу страницы скачай artifact **`myos-emulator-debug-apk`**.
11. Внутри будет `app-debug.apk`. Скачай его на телефон и установи.

## Если GitHub не показывает `.github`

В GitHub можно создать файл `.github/workflows/build-apk.yml` вручную через **Add file → Create new file**, но проще загрузить папку целиком через браузер GitHub с включёнными скрытыми файлами.

## Что собирается

- Android 8.0+ (API 26+)
- debug APK
- Android Gradle Plugin 8.5.2
- Gradle 8.7
- compileSdk 35
- Java 17

## Важно

Эмулятор запускает MyOS `.app` в пользовательском режиме. Совместимость зависит от набора x86-инструкций и syscall'ов, реализованных в VM. Это не эмулятор всего x86-PC и не гарантирует запуск буквально любого бинарника.
