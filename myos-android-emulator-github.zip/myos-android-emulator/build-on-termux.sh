#!/data/data/com.termux/files/usr/bin/bash
set -e
pkg update -y
pkg install -y openjdk-17 wget unzip
# Android SDK is not bundled; GitHub Actions is the recommended phone-only build path.
echo "Для сборки на телефоне без Android SDK используйте GitHub Actions из README-GITHUB.md."
